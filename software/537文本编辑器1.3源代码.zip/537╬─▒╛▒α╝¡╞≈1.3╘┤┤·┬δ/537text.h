#define CM_FILE_OPEN	9072
#define CM_FILE_SAVEAS	9071
#define CM_FILE_EXIT	9070
#define CM_ABOUT        9069
#define CM_HELP         9068

#define IDC_MAIN_TEXT 1001
