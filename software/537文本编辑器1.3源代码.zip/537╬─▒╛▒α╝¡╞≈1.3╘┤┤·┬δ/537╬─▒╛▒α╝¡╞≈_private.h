/* THIS FILE WILL BE OVERWRITTEN BY DEV-C++ */
/* DO NOT EDIT ! */

#ifndef 537�ı��༭��_PRIVATE_H
#define 537�ı��༭��_PRIVATE_H

/* VERSION DEFINITIONS */
#define VER_STRING	"1.3.0.0"
#define VER_MAJOR	1
#define VER_MINOR	3
#define VER_RELEASE	0
#define VER_BUILD	0
#define COMPANY_NAME	"Studio 537"
#define FILE_VERSION	"1.3.0.0"
#define FILE_DESCRIPTION	"537�ı��༭��"
#define INTERNAL_NAME	"537�ı��༭��32λ"
#define LEGAL_COPYRIGHT	"Copyright @2023 537text"
#define LEGAL_TRADEMARKS	"537Text"
#define ORIGINAL_FILENAME	"537text"
#define PRODUCT_NAME	"537�ı��༭��"
#define PRODUCT_VERSION	"1.3.0.0"

#endif /*537�ı��༭��_PRIVATE_H*/
