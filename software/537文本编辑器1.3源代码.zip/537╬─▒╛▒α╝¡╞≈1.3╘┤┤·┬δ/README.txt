使用条款：
所有人都可以在未经537工作室允许的情况下使用、编辑、更改及编译537文本编辑器1.3版本源代码，但是需在“关于”界面、起始界面或发布的网站上的显眼位置标明“由537文本编辑器改编”。所有人都拥有这些开源代码的使用权，但代码的内容版权归537工作室所有，任何人不得在未标明“由537文本编辑器改编”以及未经允许的情况下抄袭、借用这些代码及文件。
537工作室
2023年10月2日

使用條款：
所有人都可以在未經537工作室允許的情況下使用、編輯、更改及編譯537文本編輯器1.3版本原始程式碼，但是需在“關於”介面、起始介面或發佈的網站上的顯眼位置標明“由537文本編輯器改編”。 所有人都擁有這些開原始程式碼的使用權，但代碼的內容版權歸537工作室所有，任何人不得在未標明“由537文本編輯器改編”以及未經允許的情況下抄襲、借用這些代碼及檔。
537工作室
2023年10月2日

Terms of Use:
Everyone may use, edit, change, and compile the 537 Text Editor version 1.3 source code without the permission of 537 Studios, provided that "adapted by 537 Text Editor" is prominently marked on the "About" screen, the start screen, or on the published website. Everyone owns the right to use the open source code, but the copyright of the content of the code belongs to 537 Studios, and no one may copy or borrow these code and files without the indication of "adapted by 537 text editor" and without permission.
537 Studio
October 2, 2023